package com.example.studentregistar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    EditText user,pass,nam;
    Button lgin;
    ArrayList<Member> memberList = new ArrayList<Member>();
    public static String memberName="";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        fillData();
        //initials
        nam=findViewById(R.id.nm);
        user=findViewById(R.id.username);
        pass=findViewById(R.id.passward);
        lgin=findViewById(R.id.login);
        //method
        lgin.setOnClickListener(this);

    }
    public void fillData(){
        memberList.add(new Member("Kirna","kirnabamrah","2345678"));
    }

    @Override
    public void onClick(View v) {
        String check = checkLogin(nam.getText().toString(),user.getText().toString(),pass.getText().toString());
        if (check.isEmpty())
            Toast.makeText(getApplicationContext(),"Invalid username or pssword",Toast.LENGTH_LONG).show();
        else
        {
            memberName=check;
            //navigate to the MainActivity
            Intent intent = new Intent(this,MainActivity.class);
            startActivity(intent);

        }

    }
    //method to verify the username and password
    public String checkLogin(String name,String username, String password){
        for(int i=0;i<memberList.size();i++)
            if(name.equals(memberList.get(i).getName()))
                if(username.equals(memberList.get(i).getUserName()))
                    if(password.equals(memberList.get(i).getPassward()))
                        return memberList.get(i).getName();
        return "";
    }



}

