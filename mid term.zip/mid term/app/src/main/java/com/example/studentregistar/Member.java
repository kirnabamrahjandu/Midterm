package com.example.studentregistar;

public class Member {
    private String name;
    private String userName;
    private String passward;

    public Member(String name, String userName, String passward) {
        this.name = name;
        this.userName = userName;
        this.passward = passward;
    }

    public String getName() {
        return name;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassward() {
        return passward;
    } public void setName(String name) {
        this.name = name;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setPassward(String passward) {
        this.passward = passward;
    }
}




