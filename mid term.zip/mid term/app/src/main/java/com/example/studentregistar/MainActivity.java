package com.example.studentregistar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener,View.OnClickListener, CompoundButton.OnCheckedChangeListener {
    TextView tx1,tx2;
    Button btn;
    Spinner sp1;
    RadioButton RB1,RB2;
    CheckBox CH1,CH2;
    ArrayList<Subject> subjectList= new ArrayList<Subject>();
    ArrayList<String> SubjectTitle = new ArrayList<>();
    public static double originalPrice =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tx1=findViewById(R.id.fees);
        tx2=findViewById(R.id.hours);
        btn=findViewById(R.id.bt);
        sp1=findViewById(R.id.sp);
        RB1=findViewById(R.id.rb1);
        RB2=findViewById(R.id.rb2);
        CH1=findViewById(R.id.cb1);
        
        
        //filling data
        fillingData();
        //filling spinner
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,SubjectTitle);
        sp1.setAdapter(aa);




        sp1.setOnItemSelectedListener(this);
        btn.setOnClickListener(this);
        RB1.setOnClickListener(this);
        RB2.setOnClickListener(this);

        CH1.setOnCheckedChangeListener(this);
        CH2.setOnCheckedChangeListener(this);





    }
    public void fillingData(){
        subjectList.add(new Subject("Java",1300,6));
        subjectList.add(new Subject("Swift",1500,5));
        subjectList.add(new Subject("iOS",1350,5));
        subjectList.add(new Subject("Android",1400,7));
        subjectList.add(new Subject("Database",1000,4));
        for(int i=0;i<subjectList.size();i++){
            SubjectTitle.add(subjectList.get(i).getTitle());
        }



    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
        tx1.setText(subjectList.get(i).getFees());
        tx2.setText(subjectList.get(i).getHours());

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {
        double oldPrice = MainActivity.originalPrice;
        switch (v.getId()) {
            case R.id.bt:
                tx1.setText(String.valueOf(oldPrice + originalPrice));
                break;
            case R.id.rb1:
                if(oldPrice < 19){
                tx1.setText(String.valueOf(oldPrice + originalPrice));}
                else
                    {
                        Toast.makeText(getApplicationContext(),"not allowed",Toast.LENGTH_LONG).show();

                    }
                break;
            case R.id.rb2:
                if(oldPrice < 21) {
                    tx1.setText(String.valueOf(oldPrice + originalPrice));

                }
                else{
                    Toast.makeText(getApplicationContext(),"not alloewd",Toast.LENGTH_LONG).show();
                }
                break;


        }

    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        double total = Double.parseDouble(tx1.getText().toString());
        switch(compoundButton.getId()) {
            case R.id.cb1:
                total += 1000;
                tx1.setText(String.format("%.2f", total));
            case R.id.cb2:
                total += 2;
                tx1.setText(String.format("%.2f",total));
    }

}
}