package com.example.studentregistar;

public class Subject {
    private String Title;
    private int Fees;
    private int Hours;

    public Subject(String title, int fees, int hours) {
        Title = title;
        Fees = fees;
        Hours = hours;
    }

    public String getTitle() {
        return Title;
    }

    public int getFees() {
        return Fees;
    }

    public int getHours() {
        return Hours;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public void setFees(int fees) {
        Fees = fees;
    }

    public void setHours(int hours) {
        Hours = hours;
    }
}
